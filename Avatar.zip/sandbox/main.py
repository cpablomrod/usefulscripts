import avatar
import random

# Determine the bow location (1 = hair bow, 2 = bowtie, 3 = no bow)
bow = random.randint(1, 3)

# If it's a hair bow, draw it first
if bow == 1:
    avatar.draw_bow()

# Draw facial features (common to all cases)
avatar.draw_eyes("medium")

# Nose will randomly be either a triangle or a button.
shape = random.randint(1, 2)
if shape == 1:
    avatar.draw_nose("triangle")
else:
    avatar.draw_nose("button")

# We have 3 options for the mouth
expression = random.randint(1, 4)
if expression in [1, 2]:  # Smile is twice as likely
    avatar.draw_mouth("smile")
elif expression == 3:
    avatar.draw_mouth("neutral")
else:  # expression == 4
    avatar.draw_mouth("teeth")

# If it's a bowtie, draw the bow last
if bow == 2:
    avatar.draw_bow()  