def show_screen(ball_position, output_width):
    """Returns a string representing the screen with the ball at ball_position."""
    screen = ['-'] * output_width
    index = int(round(ball_position))
    index = max(0, min(index, output_width - 1))  # clamp to valid range
    screen[index] = 'o'
    return ''.join(screen)